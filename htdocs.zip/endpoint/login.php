<?php
session_start();
include("../conn/conn.php");


if(isset($_POST["login"]))
{
    $e=$_POST['email'];
    $p=$_POST['pass'];

    $ins="SELECT * FROM tbl_user WHERE username='$e' AND password='$p' ";
    $rs=$con->query($ins);

    if($rs->num_rows>0)
    {
        $res=$rs->fetch_assoc();
        $_SESSION['sn']=$res['name'];

        header("location:/home/index.html");

    }
    else
    {
        echo "INVALID LOGIN";
        header("Refresh 3;url=index.php");
    }
}
?>