<?php
$con=mysqli_connect("75.119.143.201","gdcladmin","GDCLadmin@123","GDCL");
?>